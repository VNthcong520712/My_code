# One-Axis-Reaction-Wheel-Stick

Arduino mini, Nidec 24H motors, MPU6050, 3S 500 mAh LiPo battery.

Balancing controller can be tuned remotely over bluetooth.

Example (change K1):

Send p+ (or p+p+p+p+p+p+p+) for increase K1.

Send p- (or p-p-p-p-p-p-p-) for decrease K1.

<img src="/pictures/stick1.jpg" alt="Balancing stick pic"/>
 
More about this:

https://youtu.be/qGbiZseBd_o